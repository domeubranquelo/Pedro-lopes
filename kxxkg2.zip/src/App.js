const user = {
  name: 'Pedro Lopes',
  imageUrl: 'pedrolindao.jpg',
  imageSize: 90,
};

export default function Profile() {
  return (
    <>
      <h1>{user.name}</h1>
      <img
        className="avatar"
        src={user.pedrolindao}
        alt={'Photo of ' + user.name}
        style={{
          width: user.imageSize,
          height: user.imageSize
        }}
      />
      <h2> oi eu sou o pedro faço desenvolvimento de sistemas e odeio o meu curso</h2>
      <p> tenho 16 anos, quase namoro o gui, tenho um golden incrivel
        chamado Bento </p>
    </>
  );
}
